﻿using SectionManager.Drawer;
using SectionManager.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SectionManager {
    public class SectionControl : Control {

        private Layer layer;
        private Bitmap bitmap;
        private Rectangle box;
        private ZoomPer zoom = ZoomPer.z100;
        private List<BoxGroup> _boxGroupList;
        public ZoomPer Zoom { set => zoom = value; }

        private bool thRunning;
        private Thread thUpdate;

        private object paintLock = new object();
        private object thLock = new object();

        public SectionControl() {
            DoubleBuffered = true;

            box = new Rectangle(0,0,16,16);

            thRunning = true;
            thUpdate = new Thread(() => BoxUpdate());
            thUpdate.Start();
        }


        protected override void OnPaint(PaintEventArgs e) {
            base.OnPaint(e);
            /*
            
            배경은 아무리 커도 현재 zoom 크기 대비하여 이미지를 해당 사이즈에 맞게 잘라서 표출, 
            그려지는 박스들의 사이즈 중 캔버스를 벗어나는 사이즈가 있으면 
            overflow되는 사이즈 + a 값만큼 캔버스 다시 그리고 해당 방향에 스크롤을 넣어준다.
            배경은 박스가 추가되거나 움직였을때 사이즈가 변동되었다는 이벤트를 발생시켜 SectionControl에서 감지한다

            */

            if (layer != null) { 

                var bitmap = layer.Bitmap;

                e.Graphics.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighSpeed;
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighSpeed;
                e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
                e.Graphics.DrawImage(bitmap, ClientRectangle, box, GraphicsUnit.Pixel);

                DrawTracker(e.Graphics);
            }
        }

        private void DrawBoxGroup(Layer layer) {
            using (var g = Graphics.FromImage(layer.Bitmap)) {
                for (int i = 0; i < _boxGroupList.Count; i++) {
                    var boxList = _boxGroupList[i].BoxList;
                    for (int j = 0; j < boxList.Count; j++) {
                        g.DrawRectangle(new Pen(new SolidBrush(Color.Black),2 ),boxList[j].Rect);
                    }
                }
            }
        }

        private void DrawTracker(Graphics g) {
            // zoom에 따라 변경
        }

        public void SetModelValue(List<BoxGroup> listBoxGroup) {
            _boxGroupList = listBoxGroup;

        }

        public void RegistBox(int width, int height) { 

        }
        public void DeleteBox() { }

        public void SetViewSize(int width, int height) {
            box = new Rectangle(new Point(0,0), new Size(width, height));

            // draw background
            // 그리드를 해당 사이즈로 조절
        }

        public void SetLayerSize(int width, int height) {
            layer = new Layer(width, height);
        }

        public void BoxUpdate() {
            while (thRunning) {
                lock (thLock) {
                    if (layer != null) {
                        layer.Clear();
                        DrawBoxGroup(layer);
                        Invalidate(false);
                    }
                }
            }
        }


    }
}
